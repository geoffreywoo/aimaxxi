# Life After Scarcity — cast starter pack v1

Three fictional character pieces extracted from the original deterministic SVG for **Late Checkout**:

- `anti-hunter.svg` / `.png`: Anti Hunter, standing in his dark suit.
- `temp-reading.svg` / `.png`: the Temp reading, including her chair and book.
- `robot.svg` / `.png`: the standing green robot.

SVGs contain named movable groups and no background. PNGs have transparent canvases. Import a piece into your drawing app, or copy its group into `three-panel-template.svg`. Move, recolour or redraw it; the included template and PNG sheet are existing blank story tools. This is a starter set of these three poses, not an animation or every possible pose.

Make an original fictional scene where machines succeed and institutions stay absurd. Give each character a goal and show the last action changing the situation. A cutout or a new caption alone does not create a new story.

Credit: **Community-made scene by [your name]. Source pieces: Anti Hunter / AI/MAXXI — Life After Scarcity.** Preserve any other creator’s credit. The existing project community-use permission is included verbatim as `COMMUNITY-USE.md`; this pack does not expand it.

Original artwork: https://antihunter.com/scarcity/late-checkout
Writers’ room and contribution instructions: https://aimaxxi.com/life-after-scarcity

A public submission is not blanket permission for AI/MAXXI to reproduce your work. Include your original source, requested credit and yes/no permission to feature. No token, wallet, payment or private information is needed. The download itself is not a submission or permission to feature.

All characters, events and capabilities are fictional. This pack contains no external scripts, fonts, links to embedded resources or submission form. No model/image generation was used for this extraction.
